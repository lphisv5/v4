export interface Game {
  _id: string;
  name: string;
  imageUrl?: string;
  gameId?: number;
}

export interface Script {
  _id: string;
  title: string;
  script: string;
  views: number;
  likeCount: number;
  dislikeCount: number;
  verified: boolean;
  key: boolean;
  isUniversal: boolean;
  isPatched: boolean;
  scriptType: 'free' | 'paid';
  createdAt: string;
  lastBump: string;
  image?: string;
  game?: Game;
  slug?: string;
}

export interface ScriptResponse {
  result: {
    scripts: Script[];
    totalPages: number;
    currentPage: number;
    totalScripts?: number;
  };
}

export interface FilterState {
  mode: '' | 'free' | 'paid';
  verified: '' | '1' | '0';
  key: boolean;
  universal: boolean;
  hidePatched: boolean;
  sortBy: 'createdAt' | 'views' | 'likeCount' | 'lastBump';
  order: 'desc' | 'asc';
}

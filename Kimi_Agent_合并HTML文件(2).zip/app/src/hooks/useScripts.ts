import { useState, useCallback, useRef } from 'react';
import type { Script, FilterState, ScriptResponse } from '@/types/script';

const API_BASE = 'https://scriptblox.com/api';

// Sample fallback scripts for when API fails
const fallbackScripts: Script[] = [
  {
    _id: 'demo1',
    title: 'Blox Fruits Auto Farm - Free Script',
    script: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/..."))()',
    views: 1250000,
    likeCount: 45000,
    dislikeCount: 1200,
    verified: true,
    key: false,
    isUniversal: false,
    isPatched: false,
    scriptType: 'free',
    createdAt: '2024-01-15T10:30:00Z',
    lastBump: '2024-03-20T08:00:00Z',
    image: 'https://placehold.co/480x270/1e3a5f/60a5fa?text=Blox+Fruits',
    game: { _id: 'g1', name: 'Blox Fruits', imageUrl: '' }
  },
  {
    _id: 'demo2',
    title: 'Adopt Me Auto Pet Farm - Universal',
    script: 'loadstring(game:HttpGet("https://pastebin.com/raw/..."))()',
    views: 890000,
    likeCount: 32000,
    dislikeCount: 800,
    verified: true,
    key: true,
    isUniversal: true,
    isPatched: false,
    scriptType: 'free',
    createdAt: '2024-02-01T14:00:00Z',
    lastBump: '2024-03-19T16:30:00Z',
    image: 'https://placehold.co/480x270/3f1e5f/a78bfa?text=Adopt+Me',
    game: { _id: 'g2', name: 'Adopt Me!', imageUrl: '' }
  },
  {
    _id: 'demo3',
    title: 'Jailbreak Auto Rob - Premium',
    script: 'loadstring(game:HttpGet("https://cdn.example.com/script.lua"))()',
    views: 560000,
    likeCount: 18000,
    dislikeCount: 450,
    verified: true,
    key: false,
    isUniversal: false,
    isPatched: false,
    scriptType: 'paid',
    createdAt: '2024-01-20T09:15:00Z',
    lastBump: '2024-03-18T11:00:00Z',
    image: 'https://placehold.co/480x270/5f1e1e/fa7a7a?text=Jailbreak',
    game: { _id: 'g3', name: 'Jailbreak', imageUrl: '' }
  },
  {
    _id: 'demo4',
    title: 'MM2 Auto Farm & ESP - Free',
    script: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/mm2/..."))()',
    views: 780000,
    likeCount: 28000,
    dislikeCount: 600,
    verified: false,
    key: false,
    isUniversal: false,
    isPatched: true,
    scriptType: 'free',
    createdAt: '2023-12-10T16:45:00Z',
    lastBump: '2024-02-28T10:00:00Z',
    image: 'https://placehold.co/480x270/5f3f1e/faca7a?text=MM2',
    game: { _id: 'g4', name: 'Murder Mystery 2', imageUrl: '' }
  },
  {
    _id: 'demo5',
    title: 'Arsenal Silent Aim - Verified',
    script: 'loadstring(game:HttpGet("https://pastebin.com/raw/arsenal..."))()',
    views: 420000,
    likeCount: 15000,
    dislikeCount: 300,
    verified: true,
    key: true,
    isUniversal: false,
    isPatched: false,
    scriptType: 'free',
    createdAt: '2024-02-15T11:30:00Z',
    lastBump: '2024-03-20T07:00:00Z',
    image: 'https://placehold.co/480x270/1e5f3f/7afaca?text=Arsenal',
    game: { _id: 'g5', name: 'Arsenal', imageUrl: '' }
  },
  {
    _id: 'demo6',
    title: 'King Legacy Auto Quest - Universal Hub',
    script: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/hub/..."))()',
    views: 340000,
    likeCount: 12000,
    dislikeCount: 250,
    verified: true,
    key: false,
    isUniversal: true,
    isPatched: false,
    scriptType: 'free',
    createdAt: '2024-01-05T08:00:00Z',
    lastBump: '2024-03-19T20:00:00Z',
    image: 'https://placehold.co/480x270/3f5f1e/b8fa7a?text=King+Legacy',
    game: { _id: 'g6', name: 'King Legacy', imageUrl: '' }
  }
];

export function useScripts() {
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [usingFallback, setUsingFallback] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  const buildSearchUrl = useCallback((query: string, page: number, filters: FilterState): string => {
    const params = new URLSearchParams();
    params.set('q', query.trim() || ' ');
    params.set('page', page.toString());
    params.set('max', '20');
    
    if (filters.mode) params.set('mode', filters.mode);
    if (filters.verified !== '') params.set('verified', filters.verified);
    if (filters.key) params.set('key', 'true');
    if (filters.universal) params.set('universal', 'true');
    if (filters.hidePatched) params.set('patched', 'false');
    params.set('sortBy', filters.sortBy);
    params.set('order', filters.order);
    
    return `${API_BASE}/script/search?${params.toString()}`;
  }, []);

  const fetchAPI = useCallback(async (url: string): Promise<ScriptResponse | null> => {
    try {
      const controller = new AbortController();
      abortControllerRef.current = controller;
      
      const res = await fetch(url, {
        headers: { 'Accept': 'application/json' },
        signal: controller.signal,
        mode: 'cors'
      });
      
      if (res.ok) {
        const data = await res.json();
        return data as ScriptResponse;
      }
    } catch (e) {
      console.log('Direct fetch failed, trying fallback');
    }
    return null;
  }, []);

  const filterFallbackScripts = useCallback((query: string, filters: FilterState): Script[] => {
    let filtered = [...fallbackScripts];
    
    // Search filter
    if (query && query.trim() && query !== 'free') {
      const q = query.toLowerCase();
      filtered = filtered.filter(s => 
        s.title.toLowerCase().includes(q) || 
        s.game?.name.toLowerCase().includes(q)
      );
    }
    
    // Mode filter
    if (filters.mode) {
      filtered = filtered.filter(s => s.scriptType === filters.mode);
    }
    
    // Verified filter
    if (filters.verified === '1') {
      filtered = filtered.filter(s => s.verified);
    } else if (filters.verified === '0') {
      filtered = filtered.filter(s => !s.verified);
    }
    
    // Key filter
    if (filters.key) {
      filtered = filtered.filter(s => s.key);
    }
    
    // Universal filter
    if (filters.universal) {
      filtered = filtered.filter(s => s.isUniversal);
    }
    
    // Hide patched
    if (filters.hidePatched) {
      filtered = filtered.filter(s => !s.isPatched);
    }
    
    // Sort
    filtered.sort((a, b) => {
      const sortKey = filters.sortBy;
      const order = filters.order === 'asc' ? 1 : -1;
      
      if (sortKey === 'createdAt' || sortKey === 'lastBump') {
        return (new Date(a[sortKey]).getTime() - new Date(b[sortKey]).getTime()) * order;
      }
      return ((a[sortKey] || 0) - (b[sortKey] || 0)) * order;
    });
    
    return filtered;
  }, []);

  const loadScripts = useCallback(async (
    query: string,
    filters: FilterState,
    reset: boolean = true
  ): Promise<number> => {
    if (loading) return 0;
    
    // Cancel previous request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    setLoading(true);
    setError(null);

    const page = reset ? 1 : currentPage + 1;
    
    try {
      const url = buildSearchUrl(query, page, filters);
      const data = await fetchAPI(url);
      
      if (data?.result?.scripts && data.result.scripts.length > 0) {
        const newScripts = data.result.scripts;
        const total = data?.result?.totalPages || 1;
        
        if (reset) {
          setScripts(newScripts);
          setCurrentPage(1);
        } else {
          setScripts(prev => [...prev, ...newScripts]);
          setCurrentPage(page);
        }
        
        setTotalPages(total);
        setHasMore(page < total);
        setUsingFallback(false);
        
        return newScripts.length;
      } else {
        // Use fallback data
        const fallback = filterFallbackScripts(query, filters);
        setScripts(fallback);
        setCurrentPage(1);
        setTotalPages(1);
        setHasMore(false);
        setUsingFallback(true);
        return fallback.length;
      }
    } catch (err) {
      // Use fallback on error
      const fallback = filterFallbackScripts(query, filters);
      setScripts(fallback);
      setCurrentPage(1);
      setTotalPages(1);
      setHasMore(false);
      setUsingFallback(true);
      return fallback.length;
    } finally {
      setLoading(false);
    }
  }, [buildSearchUrl, currentPage, fetchAPI, filterFallbackScripts, loading]);

  const quickLoad = useCallback(async (
    query: string,
    filters: FilterState,
    maxPages: number = 5,
    onProgress?: (page: number, total: number) => void
  ): Promise<number> => {
    if (loading) return 0;
    
    setLoading(true);
    setError(null);
    
    const allScripts: Script[] = [];
    
    try {
      for (let p = 1; p <= maxPages; p++) {
        onProgress?.(p, maxPages);
        
        const url = buildSearchUrl(query, p, filters);
        const data = await fetchAPI(url);
        
        if (data?.result?.scripts?.length) {
          allScripts.push(...data.result.scripts);
        } else {
          break;
        }
        
        // Small delay to prevent rate limiting
        if (p < maxPages) {
          await new Promise(r => setTimeout(r, 150));
        }
      }
      
      if (allScripts.length > 0) {
        setScripts(allScripts);
        setCurrentPage(1);
        setHasMore(false);
        setUsingFallback(false);
        return allScripts.length;
      } else {
        // Use fallback
        const fallback = filterFallbackScripts(query, filters);
        setScripts(fallback);
        setCurrentPage(1);
        setHasMore(false);
        setUsingFallback(true);
        return fallback.length;
      }
    } catch (err) {
      // Use fallback on error
      const fallback = filterFallbackScripts(query, filters);
      setScripts(fallback);
      setCurrentPage(1);
      setHasMore(false);
      setUsingFallback(true);
      return fallback.length;
    } finally {
      setLoading(false);
    }
  }, [buildSearchUrl, fetchAPI, filterFallbackScripts, loading]);

  return {
    scripts,
    loading,
    error,
    hasMore,
    currentPage,
    totalPages,
    usingFallback,
    loadScripts,
    quickLoad,
    setScripts
  };
}

import { FileSearch } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface EmptyStateProps {
  onReset: () => void;
}

export function EmptyState({ onReset }: EmptyStateProps) {
  return (
    <div className="col-span-full flex flex-col items-center justify-center py-16 text-center">
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-[#21262d]">
        <FileSearch className="h-8 w-8 text-slate-500" />
      </div>
      <h3 className="mb-2 text-lg font-semibold text-white">No scripts found</h3>
      <p className="mb-6 max-w-sm text-sm text-slate-400">
        Try adjusting your search query or filters to find what you're looking for.
      </p>
      <Button
        onClick={onReset}
        variant="outline"
        className="rounded-full border-white/10 bg-transparent text-white hover:bg-white/5"
      >
        Clear filters
      </Button>
    </div>
  );
}

import { useState, useRef, useEffect } from 'react';
import type { Script } from '@/types/script';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Check, 
  Key, 
  Crown, 
  Globe, 
  AlertTriangle, 
  Eye, 
  ThumbsUp, 
  ThumbsDown,
  Calendar,
  Clock,
  Gamepad2,
  Copy,
  CheckCheck
} from 'lucide-react';

interface ScriptCardProps {
  script: Script;
}

function formatNumber(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
  return n.toString();
}

function formatDate(dateStr: string): string {
  try {
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  } catch {
    return 'Unknown';
  }
}

export function ScriptCard({ script }: ScriptCardProps) {
  const [copied, setCopied] = useState(false);
  const [imageError, setImageError] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current && script.script) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
    }
  }, [script.script]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(script.script || '');
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Copy failed:', err);
    }
  };

  const imageUrl = imageError 
    ? `https://placehold.co/480x270/1e2632/377dff?text=${encodeURIComponent(script.game?.name || 'Script')}`
    : (script.image || script.game?.imageUrl || `https://placehold.co/480x270/1e2632/377dff?text=${encodeURIComponent(script.game?.name || 'Script')}`);

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-white/5 bg-[#161b22] transition-all duration-300 hover:border-blue-500/30 hover:shadow-xl hover:shadow-blue-500/5 hover:-translate-y-1">
      {/* Image */}
      <div className="relative aspect-video overflow-hidden bg-[#0d1117]">
        <img
          src={imageUrl}
          alt={script.title}
          loading="lazy"
          onError={() => setImageError(true)}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        
        {/* Badges */}
        <div className="absolute right-2 top-2 flex flex-wrap justify-end gap-1">
          {script.verified && (
            <Badge className="bg-emerald-500/90 text-white border-0 text-[10px] font-semibold px-2 py-0.5">
              <Check className="mr-1 h-3 w-3" /> Verified
            </Badge>
          )}
          {script.key && (
            <Badge className="bg-amber-500/90 text-black border-0 text-[10px] font-semibold px-2 py-0.5">
              <Key className="mr-1 h-3 w-3" /> Key
            </Badge>
          )}
          {script.scriptType === 'paid' && (
            <Badge className="bg-rose-500/90 text-white border-0 text-[10px] font-semibold px-2 py-0.5">
              <Crown className="mr-1 h-3 w-3" /> Premium
            </Badge>
          )}
          {script.isUniversal && (
            <Badge className="bg-blue-500/90 text-white border-0 text-[10px] font-semibold px-2 py-0.5">
              <Globe className="mr-1 h-3 w-3" /> Universal
            </Badge>
          )}
          {script.isPatched && (
            <Badge className="bg-slate-500/90 text-white border-0 text-[10px] font-semibold px-2 py-0.5">
              <AlertTriangle className="mr-1 h-3 w-3" /> Patched
            </Badge>
          )}
        </div>

        {/* Views */}
        <div className="absolute bottom-2 left-2 flex items-center gap-1 rounded-full bg-black/60 px-2 py-0.5 text-xs text-white backdrop-blur-sm">
          <Eye className="h-3 w-3" />
          {formatNumber(script.views || 0)}
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col gap-3 p-4">
        {/* Title */}
        <h3 className="line-clamp-2 text-sm font-semibold text-white leading-snug">
          {script.title}
        </h3>

        {/* Game */}
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <Gamepad2 className="h-3.5 w-3.5 text-blue-400" />
          <span className="truncate">{script.game?.name || 'Universal'}</span>
        </div>

        {/* Dates */}
        <div className="flex items-center gap-3 text-[11px] text-slate-500">
          <span className="flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            {formatDate(script.createdAt)}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {formatDate(script.lastBump)}
          </span>
        </div>

        {/* Likes/Dislikes */}
        <div className="flex items-center gap-4 border-t border-white/5 pt-3 text-xs">
          <span className="flex items-center gap-1 text-emerald-400">
            <ThumbsUp className="h-3.5 w-3.5" />
            {formatNumber(script.likeCount || 0)}
          </span>
          <span className="flex items-center gap-1 text-rose-400">
            <ThumbsDown className="h-3.5 w-3.5" />
            {formatNumber(script.dislikeCount || 0)}
          </span>
        </div>

        {/* Script Box */}
        <div className="relative mt-1">
          <textarea
            ref={textareaRef}
            readOnly
            value={script.script || 'No script available'}
            className="w-full resize-none rounded-xl border border-white/10 bg-[#0d1117] p-3 pr-10 font-mono text-[11px] leading-relaxed text-slate-300 focus:outline-none focus:border-blue-500/30"
            rows={2}
          />
          <Button
            size="icon"
            variant="ghost"
            onClick={handleCopy}
            className="absolute bottom-2 right-2 h-7 w-7 rounded-full bg-[#21262d] text-slate-400 hover:bg-blue-600 hover:text-white transition-colors"
          >
            {copied ? <CheckCheck className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
          </Button>
        </div>
      </div>
    </article>
  );
}

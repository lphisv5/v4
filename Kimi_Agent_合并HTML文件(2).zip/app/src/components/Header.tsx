import { Search, SlidersHorizontal, Zap, Code2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
  onSearch: () => void;
  onToggleFilters: () => void;
  onQuickLoad: () => void;
  loading: boolean;
}

export function Header({
  searchQuery,
  onSearchChange,
  onSearch,
  onToggleFilters,
  onQuickLoad,
  loading
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/5 bg-[#161b22]/95 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-[1600px] items-center gap-4 px-4 sm:px-6">
        {/* Logo */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 shadow-lg shadow-blue-500/20">
            <Code2 className="h-5 w-5 text-white" />
          </div>
          <span className="hidden text-xl font-semibold tracking-tight text-white sm:inline">
            YANZ<span className="text-blue-400">.live</span>
          </span>
        </div>

        {/* Search */}
        <div className="flex flex-1 items-center gap-2">
          <div className="relative flex flex-1 max-w-xl">
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
              <Search className="h-4 w-4" />
            </div>
            <Input
              type="text"
              placeholder="Search scripts..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && onSearch()}
              className="h-10 w-full rounded-full border-white/10 bg-[#0d1117] pl-10 pr-4 text-sm text-white placeholder:text-slate-500 focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20"
            />
          </div>
          <Button
            onClick={onSearch}
            disabled={loading}
            className="h-10 rounded-full bg-blue-600 px-5 text-sm font-medium text-white hover:bg-blue-500 disabled:opacity-50"
          >
            {loading ? '...' : 'Search'}
          </Button>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={onToggleFilters}
            className="h-10 w-10 rounded-full border-white/10 bg-[#21262d] text-slate-300 hover:border-blue-500/50 hover:bg-[#30363d] hover:text-white"
          >
            <SlidersHorizontal className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={onQuickLoad}
            disabled={loading}
            className="h-10 w-10 rounded-full border-white/10 bg-[#21262d] text-amber-400 hover:border-amber-500/50 hover:bg-[#30363d] hover:text-amber-300"
          >
            <Zap className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}

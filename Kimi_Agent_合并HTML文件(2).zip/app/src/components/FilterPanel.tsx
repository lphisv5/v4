import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { FilterState } from '@/types/script';

interface FilterPanelProps {
  isOpen: boolean;
  onClose: () => void;
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  onApply: () => void;
  onReset: () => void;
}

export function FilterPanel({
  isOpen,
  onClose,
  filters,
  onFilterChange,
  onApply,
  onReset
}: FilterPanelProps) {
  const updateFilter = <K extends keyof FilterState>(key: K, value: FilterState[K]) => {
    onFilterChange({ ...filters, [key]: value });
  };

  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />

      {/* Panel */}
      <aside
        className={`fixed right-0 top-0 z-50 h-full w-full max-w-sm transform border-l border-white/10 bg-[#161b22] shadow-2xl transition-transform duration-300 ease-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex h-full flex-col">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-white/5 px-5 py-4">
            <h2 className="text-lg font-semibold text-white">Filters & Sorting</h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="h-8 w-8 rounded-full text-slate-400 hover:text-white hover:bg-white/5"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-5 py-5 space-y-6">
            {/* Mode */}
            <div className="space-y-2.5">
              <Label className="text-xs font-medium uppercase tracking-wider text-slate-500">
                Script Type
              </Label>
              <Select
                value={filters.mode}
                onValueChange={(value: '' | 'free' | 'paid') => updateFilter('mode', value)}
              >
                <SelectTrigger className="h-10 rounded-xl border-white/10 bg-[#0d1117] text-white focus:ring-blue-500/20">
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#21262d]">
                  <SelectItem value="" className="text-white focus:bg-white/10">All types</SelectItem>
                  <SelectItem value="free" className="text-white focus:bg-white/10">Free only</SelectItem>
                  <SelectItem value="paid" className="text-white focus:bg-white/10">Paid only</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Verified */}
            <div className="space-y-2.5">
              <Label className="text-xs font-medium uppercase tracking-wider text-slate-500">
                Verification Status
              </Label>
              <Select
                value={filters.verified}
                onValueChange={(value: '' | '1' | '0') => updateFilter('verified', value)}
              >
                <SelectTrigger className="h-10 rounded-xl border-white/10 bg-[#0d1117] text-white focus:ring-blue-500/20">
                  <SelectValue placeholder="Any" />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#21262d]">
                  <SelectItem value="" className="text-white focus:bg-white/10">Any</SelectItem>
                  <SelectItem value="1" className="text-white focus:bg-white/10">Verified only</SelectItem>
                  <SelectItem value="0" className="text-white focus:bg-white/10">Unverified only</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Sort By */}
            <div className="space-y-2.5">
              <Label className="text-xs font-medium uppercase tracking-wider text-slate-500">
                Sort By
              </Label>
              <Select
                value={filters.sortBy}
                onValueChange={(value: FilterState['sortBy']) => updateFilter('sortBy', value)}
              >
                <SelectTrigger className="h-10 rounded-xl border-white/10 bg-[#0d1117] text-white focus:ring-blue-500/20">
                  <SelectValue placeholder="Newest" />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#21262d]">
                  <SelectItem value="createdAt" className="text-white focus:bg-white/10">Newest</SelectItem>
                  <SelectItem value="views" className="text-white focus:bg-white/10">Most viewed</SelectItem>
                  <SelectItem value="likeCount" className="text-white focus:bg-white/10">Most liked</SelectItem>
                  <SelectItem value="lastBump" className="text-white focus:bg-white/10">Recently bumped</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Order */}
            <div className="space-y-2.5">
              <Label className="text-xs font-medium uppercase tracking-wider text-slate-500">
                Order
              </Label>
              <Select
                value={filters.order}
                onValueChange={(value: 'desc' | 'asc') => updateFilter('order', value)}
              >
                <SelectTrigger className="h-10 rounded-xl border-white/10 bg-[#0d1117] text-white focus:ring-blue-500/20">
                  <SelectValue placeholder="Descending" />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#21262d]">
                  <SelectItem value="desc" className="text-white focus:bg-white/10">Descending</SelectItem>
                  <SelectItem value="asc" className="text-white focus:bg-white/10">Ascending</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Toggles */}
            <div className="space-y-3">
              <Label className="text-xs font-medium uppercase tracking-wider text-slate-500">
                Additional Filters
              </Label>
              
              <div className="flex items-center justify-between rounded-xl border border-white/5 bg-[#0d1117] p-3">
                <span className="text-sm text-slate-300">Key required</span>
                <Switch
                  checked={filters.key}
                  onCheckedChange={(checked) => updateFilter('key', checked)}
                  className="data-[state=checked]:bg-blue-600"
                />
              </div>

              <div className="flex items-center justify-between rounded-xl border border-white/5 bg-[#0d1117] p-3">
                <span className="text-sm text-slate-300">Universal only</span>
                <Switch
                  checked={filters.universal}
                  onCheckedChange={(checked) => updateFilter('universal', checked)}
                  className="data-[state=checked]:bg-blue-600"
                />
              </div>

              <div className="flex items-center justify-between rounded-xl border border-white/5 bg-[#0d1117] p-3">
                <span className="text-sm text-slate-300">Hide patched</span>
                <Switch
                  checked={filters.hidePatched}
                  onCheckedChange={(checked) => updateFilter('hidePatched', checked)}
                  className="data-[state=checked]:bg-blue-600"
                />
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="border-t border-white/5 p-5 space-y-3">
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={onReset}
                className="flex-1 h-10 rounded-full border-white/10 bg-transparent text-slate-300 hover:bg-white/5 hover:text-white"
              >
                Reset
              </Button>
              <Button
                onClick={onApply}
                className="flex-1 h-10 rounded-full bg-blue-600 text-white hover:bg-blue-500"
              >
                Apply Filters
              </Button>
            </div>
            <p className="text-center text-[10px] text-slate-600">
              Powered by ScriptBlox API
            </p>
          </div>
        </div>
      </aside>
    </>
  );
}

import { Database, FileCode, Layers } from 'lucide-react';

interface StatsBarProps {
  totalCount: number;
  showingCount: number;
  currentPage: number;
  totalPages: number;
}

function formatNumber(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
  return n.toString();
}

export function StatsBar({ totalCount, showingCount, currentPage, totalPages }: StatsBarProps) {
  return (
    <div className="w-full border-b border-white/5 bg-[#0d1117]/80">
      <div className="mx-auto flex h-10 max-w-[1600px] items-center justify-between px-4 sm:px-6">
        <div className="flex items-center gap-6 text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <Database className="h-3.5 w-3.5 text-blue-500" />
            <span className="hidden sm:inline">Total:</span>
            <span className="font-medium text-slate-200">{formatNumber(totalCount)}</span>
          </span>
          <span className="flex items-center gap-1.5">
            <FileCode className="h-3.5 w-3.5 text-emerald-500" />
            <span className="hidden sm:inline">Showing:</span>
            <span className="font-medium text-slate-200">{formatNumber(showingCount)}</span>
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <Layers className="h-3.5 w-3.5 text-purple-500" />
          <span>Page</span>
          <span className="font-medium text-slate-200">{currentPage}</span>
          <span>/</span>
          <span>{totalPages || 1}</span>
        </div>
      </div>
    </div>
  );
}

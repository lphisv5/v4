import { AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ErrorStateProps {
  message: string;
  onRetry: () => void;
}

export function ErrorState({ message, onRetry }: ErrorStateProps) {
  return (
    <div className="col-span-full flex flex-col items-center justify-center py-16 text-center">
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-rose-500/10">
        <AlertCircle className="h-8 w-8 text-rose-500" />
      </div>
      <h3 className="mb-2 text-lg font-semibold text-white">Something went wrong</h3>
      <p className="mb-6 max-w-sm text-sm text-slate-400">{message}</p>
      <Button
        onClick={onRetry}
        className="rounded-full bg-blue-600 text-white hover:bg-blue-500"
      >
        <RefreshCw className="mr-2 h-4 w-4" />
        Try again
      </Button>
    </div>
  );
}

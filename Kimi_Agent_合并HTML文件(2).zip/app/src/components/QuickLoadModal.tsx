import { Zap } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

interface QuickLoadModalProps {
  isOpen: boolean;
  progress: number;
  status: string;
}

export function QuickLoadModal({ isOpen, progress, status }: QuickLoadModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <div className="mx-4 w-full max-w-sm rounded-3xl border border-white/10 bg-[#161b22] p-8 text-center shadow-2xl">
        <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 shadow-lg shadow-amber-500/20">
          <Zap className="h-8 w-8 text-white" />
        </div>
        
        <h3 className="mb-2 text-xl font-semibold text-white">Quick Loading</h3>
        <p className="mb-6 text-sm text-slate-400">{status}</p>
        
        <div className="space-y-2">
          <Progress 
            value={progress} 
            className="h-2 bg-[#0d1117]"
          />
          <p className="text-xs text-slate-500">{Math.round(progress)}% complete</p>
        </div>
      </div>
    </div>
  );
}

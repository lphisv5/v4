export function SkeletonCard() {
  return (
    <div className="flex flex-col overflow-hidden rounded-2xl border border-white/5 bg-[#161b22]">
      {/* Image skeleton */}
      <div className="aspect-video bg-[#0d1117]">
        <div className="h-full w-full animate-pulse bg-gradient-to-r from-[#21262d] via-[#30363d] to-[#21262d] bg-[length:200%_100%]" 
          style={{ animation: 'shimmer 1.5s infinite' }} />
      </div>
      
      {/* Content skeleton */}
      <div className="flex flex-1 flex-col gap-3 p-4">
        {/* Title */}
        <div className="h-4 w-3/4 animate-pulse rounded bg-[#21262d]" />
        <div className="h-4 w-1/2 animate-pulse rounded bg-[#21262d]" />
        
        {/* Game */}
        <div className="h-3 w-1/3 animate-pulse rounded bg-[#21262d]" />
        
        {/* Dates */}
        <div className="flex gap-3">
          <div className="h-3 w-20 animate-pulse rounded bg-[#21262d]" />
          <div className="h-3 w-20 animate-pulse rounded bg-[#21262d]" />
        </div>
        
        {/* Likes */}
        <div className="flex gap-4 border-t border-white/5 pt-3">
          <div className="h-3 w-12 animate-pulse rounded bg-[#21262d]" />
          <div className="h-3 w-12 animate-pulse rounded bg-[#21262d]" />
        </div>
        
        {/* Script box */}
        <div className="h-16 animate-pulse rounded-xl bg-[#0d1117]" />
      </div>
    </div>
  );
}

export function SkeletonGrid({ count = 6 }: { count?: number }) {
  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <SkeletonCard key={i} />
      ))}
    </>
  );
}

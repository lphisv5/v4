import { useState, useCallback, useEffect, useRef } from 'react';
import { useScripts } from '@/hooks/useScripts';
import { Header } from '@/components/Header';
import { StatsBar } from '@/components/StatsBar';
import { ScriptCard } from '@/components/ScriptCard';
import { FilterPanel } from '@/components/FilterPanel';
import { SkeletonGrid } from '@/components/SkeletonCard';
import { QuickLoadModal } from '@/components/QuickLoadModal';
import { EmptyState } from '@/components/EmptyState';
import { Button } from '@/components/ui/button';
import type { FilterState } from '@/types/script';
import { ChevronDown, Check, AlertTriangle, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

const defaultFilters: FilterState = {
  mode: '',
  verified: '',
  key: false,
  universal: false,
  hidePatched: false,
  sortBy: 'createdAt',
  order: 'desc'
};

function App() {
  const [searchQuery, setSearchQuery] = useState('free');
  const [filters, setFilters] = useState<FilterState>(defaultFilters);
  const [filterPanelOpen, setFilterPanelOpen] = useState(false);
  const [quickLoadOpen, setQuickLoadOpen] = useState(false);
  const [quickLoadProgress, setQuickLoadProgress] = useState(0);
  const [quickLoadStatus, setQuickLoadStatus] = useState('');
  const [hasSearched, setHasSearched] = useState(false);
  
  const { 
    scripts, 
    loading, 
    error, 
    hasMore, 
    currentPage, 
    totalPages, 
    usingFallback,
    loadScripts, 
    quickLoad 
  } = useScripts();

  // Initial load
  useEffect(() => {
    handleSearch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSearch = useCallback(async () => {
    setHasSearched(true);
    const count = await loadScripts(searchQuery, filters, true);
    if (count > 0) {
      if (usingFallback) {
        toast.info(`Showing demo data (${count} scripts)`);
      } else {
        toast.success(`Found ${count} scripts`);
      }
    }
  }, [searchQuery, filters, loadScripts, usingFallback]);

  const handleLoadMore = useCallback(async () => {
    const count = await loadScripts(searchQuery, filters, false);
    if (count > 0) {
      toast.success(`Loaded ${count} more scripts`);
    }
  }, [searchQuery, filters, loadScripts]);

  const handleQuickLoad = useCallback(async () => {
    setQuickLoadOpen(true);
    setQuickLoadProgress(0);
    setQuickLoadStatus('Starting...');

    const count = await quickLoad(
      searchQuery,
      filters,
      5,
      (page, total) => {
        setQuickLoadProgress((page / total) * 100);
        setQuickLoadStatus(`Loading page ${page} of ${total}...`);
      }
    );

    setQuickLoadOpen(false);
    if (count > 0) {
      if (usingFallback) {
        toast.info(`Showing demo data (${count} scripts)`);
      } else {
        toast.success(`Quick-loaded ${count} scripts`);
      }
    } else {
      toast.error('Quick load failed');
    }
  }, [searchQuery, filters, quickLoad, usingFallback]);

  const handleResetFilters = useCallback(() => {
    setFilters(defaultFilters);
    setSearchQuery('free');
    loadScripts('free', defaultFilters, true);
    setFilterPanelOpen(false);
    toast.info('Filters reset');
  }, [loadScripts]);

  const handleApplyFilters = useCallback(() => {
    handleSearch();
    setFilterPanelOpen(false);
  }, [handleSearch]);

  // Infinite scroll
  const observerRef = useRef<IntersectionObserver | null>(null);
  const loadMoreRef = useCallback((node: HTMLDivElement | null) => {
    if (loading) return;
    if (observerRef.current) observerRef.current.disconnect();
    
    observerRef.current = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && hasMore && !loading) {
        handleLoadMore();
      }
    });
    
    if (node) observerRef.current.observe(node);
  }, [loading, hasMore, handleLoadMore]);

  return (
    <div className="min-h-screen bg-[#0d1117]">
      <Header
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSearch={handleSearch}
        onToggleFilters={() => setFilterPanelOpen(true)}
        onQuickLoad={handleQuickLoad}
        loading={loading}
      />

      <StatsBar
        totalCount={scripts.length}
        showingCount={scripts.length}
        currentPage={currentPage}
        totalPages={totalPages}
      />

      {/* Fallback Warning */}
      {usingFallback && (
        <div className="mx-auto max-w-[1600px] px-4 pt-4 sm:px-6">
          <div className="flex items-center gap-3 rounded-xl border border-amber-500/20 bg-amber-500/10 px-4 py-3 text-sm">
            <AlertTriangle className="h-5 w-5 shrink-0 text-amber-500" />
            <div className="flex-1">
              <span className="font-medium text-amber-400">Demo Mode:</span>{' '}
              <span className="text-amber-300/80">
                API is currently unavailable. Showing sample scripts for demonstration.
              </span>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={handleSearch}
              className="shrink-0 text-amber-400 hover:bg-amber-500/20 hover:text-amber-300"
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Retry
            </Button>
          </div>
        </div>
      )}

      <main className="mx-auto max-w-[1600px] px-4 py-6 sm:px-6">
        {/* Results Grid */}
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
          {loading && scripts.length === 0 ? (
            <SkeletonGrid count={10} />
          ) : scripts.length === 0 && hasSearched ? (
            <EmptyState onReset={handleResetFilters} />
          ) : (
            <>
              {scripts.map((script) => (
                <ScriptCard key={script._id} script={script} />
              ))}
              {loading && <SkeletonGrid count={3} />}
            </>
          )}
        </div>

        {/* Load More */}
        {!loading && !error && scripts.length > 0 && (
          <div className="mt-8 flex justify-center">
            {hasMore ? (
              <div ref={loadMoreRef}>
                <Button
                  onClick={handleLoadMore}
                  disabled={loading}
                  variant="outline"
                  className="rounded-full border-white/10 bg-[#161b22] px-8 text-white hover:bg-[#21262d] hover:border-white/20"
                >
                  <ChevronDown className="mr-2 h-4 w-4" />
                  Load more
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-sm text-slate-500">
                <Check className="h-4 w-4 text-emerald-500" />
                No more scripts to load
              </div>
            )}
          </div>
        )}
      </main>

      {/* Filter Panel */}
      <FilterPanel
        isOpen={filterPanelOpen}
        onClose={() => setFilterPanelOpen(false)}
        filters={filters}
        onFilterChange={setFilters}
        onApply={handleApplyFilters}
        onReset={handleResetFilters}
      />

      {/* Quick Load Modal */}
      <QuickLoadModal
        isOpen={quickLoadOpen}
        progress={quickLoadProgress}
        status={quickLoadStatus}
      />
    </div>
  );
}

export default App;
